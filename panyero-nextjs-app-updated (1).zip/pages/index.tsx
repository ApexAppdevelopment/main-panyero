
import Head from 'next/head';

export default function Home() {
    return (
        <div>
            <Head>
                <title>Panyero App</title>
                <meta name="description" content="Welcome to the Panyero App!" />
                <link rel="icon" href="/logos/logo-light.png" />
            </Head>
            <main>
                <h1>Welcome to Panyero App</h1>
                <p>Your all-in-one solution for seamless services.</p>
            </main>
        </div>
    );
}
