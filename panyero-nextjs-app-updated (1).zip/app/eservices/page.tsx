import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { useTheme } from "next-themes"
import { ServiceGrid } from "@/components/service-grid"
import { Brain, Anchor, Compass, GraduationCap, Dice1Icon as Dice, CastleIcon as Casino, Briefcase, Zap, Droplet, Wifi, Tv, TrendingUp, Smartphone, PlusSquare, MoreHorizontal } from 'lucide-react'

const services = [
  { icon: "brain", label: "AI Assistant", href: "/ai/assistant" },
  { icon: "anchor", label: "Maritime", href: "/maritime" },
  { icon: "compass", label: "Navigation", href: "/navigation" },
  { icon: "graduation-cap", label: "Academy", href: "/review-center" },
  { icon: "dice", label: "Games", href: "/games" },
  { icon: "casino", label: "Casino", href: "/casino" },
  { icon: "briefcase", label: "Careers", href: "/job-board" },
  { icon: "zap", label: "Electricity", href: "/electricity-bill" },
  { icon: "droplet", label: "Water", href: "/water-bill" },
  { icon: "wifi", label: "Internet", href: "/internet-bill" },
  { icon: "tv", label: "Television", href: "/cable-tv-bill" },
  { icon: "trending-up", label: "Investment", href: "/stocks" },
  { icon: "smartphone", label: "Mobile", href: "/mobile-load" },
  { icon: "plus-square", label: "Medical", href: "/health-insurance" },
  { icon: "more-horizontal", label: "Other", href: "/more" },
]

export default function EservicesPage() {
  const { theme } = useTheme()
  return (
    <main className={`min-h-screen pb-24 ${theme === 'dark' ? 'bg-gray-900 text-white' : 'bg-gray-50 text-black'}`}>
      <StickyHeader />
      <div className="p-4 space-y-6 text-black dark:text-white">
        <h1 className="text-2xl font-bold">Services</h1>
        <ServiceGrid services={services} />
      </div>
      <BottomNav />
    </main>
  )
}

