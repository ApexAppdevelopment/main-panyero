import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { WalletView } from "@/components/wallet-view"

export default function WalletPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      <WalletView />
      <BottomNav />
    </main>
  )
}

