import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Ticket } from 'lucide-react'

export default function MovieTicketsPage() {
  return <PlaceholderServicePage title="Movie Tickets" icon={Ticket} />
}

