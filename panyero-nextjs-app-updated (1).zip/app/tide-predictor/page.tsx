import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Timer } from 'lucide-react'

export default function TidePredictorPage() {
  return <PlaceholderServicePage title="Tide Predictor" icon={Timer} />
}

