import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Wallet } from 'lucide-react'

export default function SendMoneyPage() {
  return <PlaceholderServicePage title="Send Money" icon={Wallet} />
}

