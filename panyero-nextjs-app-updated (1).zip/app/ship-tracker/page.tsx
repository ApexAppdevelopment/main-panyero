import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Locate } from 'lucide-react'

export default function ShipTrackerPage() {
  return <PlaceholderServicePage title="Ship Tracker" icon={Locate} />
}

