import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Radar } from 'lucide-react'

export default function RadarMapPage() {
  return <PlaceholderServicePage title="Radar Map" icon={Radar} />
}

