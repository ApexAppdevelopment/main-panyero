import { NextResponse } from 'next/server'

const API_KEY = process.env.RAPIDAPI_KEY;
const API_HOST = 'openai80.p.rapidapi.com';

export async function POST(req: Request) {
  try {
    const { message } = await req.json()

    const response = await fetch(`https://${API_HOST}/chat/completions`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'X-RapidAPI-Key': API_KEY!,
        'X-RapidAPI-Host': API_HOST
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "user",
            content: message
          }
        ]
      })
    });

    const data = await response.json();
    
    return NextResponse.json({ reply: data.choices[0].message.content });
  } catch (error) {
    console.error('Error in chatbot API:', error)
    return NextResponse.json({ error: 'Failed to generate response' }, { status: 500 })
  }
}

