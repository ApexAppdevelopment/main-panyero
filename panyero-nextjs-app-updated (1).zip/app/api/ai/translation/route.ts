import { NextResponse } from 'next/server'

const API_KEY = process.env.RAPIDAPI_KEY
const API_HOST = 'google-translate1.p.rapidapi.com'

export async function POST(req: Request) {
  try {
    const { sourceText, sourceLang, targetLang } = await req.json()

    const url = `https://${API_HOST}/language/translate/v2`
    const options = {
      method: 'POST',
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
        'Accept-Encoding': 'application/gzip',
        'X-RapidAPI-Key': API_KEY!,
        'X-RapidAPI-Host': API_HOST
      },
      body: new URLSearchParams({
        q: sourceText,
        source: sourceLang,
        target: targetLang
      })
    }

    const response = await fetch(url, options)
    const result = await response.json()

    if (!response.ok) {
      throw new Error(result.message || 'Failed to translate text')
    }

    const translatedText = result.data.translations[0].translatedText

    return NextResponse.json({ translatedText })
  } catch (error) {
    console.error('Error in translation API:', error)
    return NextResponse.json({ error: 'Failed to translate text' }, { status: 500 })
  }
}

