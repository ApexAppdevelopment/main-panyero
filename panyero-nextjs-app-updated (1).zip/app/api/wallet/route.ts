import { NextResponse } from 'next/server'
import { auth } from '@/lib/firebase'
import { getWallet, updateWalletBalance, createTransaction } from '@/lib/wallet-service'

export async function POST(req: Request) {
  try {
    const { action, amount } = await req.json()
    const user = auth.currentUser

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const wallet = await getWallet(user.uid)

    if (!wallet) {
      return NextResponse.json({ error: 'Wallet not found' }, { status: 404 })
    }

    let updatedWallet

    switch (action) {
      case 'cash-in':
        updatedWallet = await updateWalletBalance(user.uid, amount, 'credit')
        await createTransaction(user.uid, 'cash_in', amount, 'PHP', 'Cash in')
        break
      case 'cash-out':
        if (wallet.balance < amount) {
          return NextResponse.json({ error: 'Insufficient funds' }, { status: 400 })
        }
        updatedWallet = await updateWalletBalance(user.uid, amount, 'debit')
        await createTransaction(user.uid, 'cash_out', -amount, 'PHP', 'Cash out')
        break
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
    }

    return NextResponse.json({ success: true, balance: updatedWallet.balance })
  } catch (error) {
    console.error('Error in wallet API:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

