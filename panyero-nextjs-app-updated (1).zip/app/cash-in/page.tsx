"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { Banknote, CreditCard, Wallet } from 'lucide-react'
import { ActivateAccount } from "@/components/activate-account"
import { getUserStatus } from "@/lib/wallet-service"

const cashInMethods = [
  {
    id: "bank",
    icon: Banknote,
    title: "Bank Transfer",
    description: "Transfer from your bank account"
  },
  {
    id: "card",
    icon: CreditCard,
    title: "Credit/Debit Card",
    description: "Use your card for instant top-up"
  },
  {
    id: "ewallet",
    icon: Wallet,
    title: "E-Wallet",
    description: "Transfer from another e-wallet"
  }
]

export default function CashInPage() {
  const { user } = useAuth()
  const [selectedMethod, setSelectedMethod] = useState("")
  const [amount, setAmount] = useState("")
  const [loading, setLoading] = useState(false)
  const [userStatus, setUserStatus] = useState<string | null>(null)

  useEffect(() => {
    const checkUserStatus = async () => {
      if (user) {
        try {
          const status = await getUserStatus(user.id)
          setUserStatus(status)
        } catch (error) {
          console.error("Error fetching user status:", error)
        }
      }
    }
    checkUserStatus()
  }, [user])

  const handleCashIn = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !selectedMethod) return

    try {
      setLoading(true)
      const response = await fetch('/api/wallet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'cash-in',
          amount: Number(amount),
        }),
      })

      const result = await response.json()

      if (result.success) {
        toast.success("Cash in successful")
        setAmount("")
        setSelectedMethod("")
      } else {
        toast.error(result.error || "Failed to cash in")
      }
    } catch (error) {
      console.error("Error cashing in:", error)
      toast.error("Failed to cash in")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">
          {userStatus === 'inactive' ? 'Activate Your Account' : 'Cash In'}
        </h1>

        {userStatus === 'inactive' ? (
          <ActivateAccount />
        ) : (
          <form onSubmit={handleCashIn} className="space-y-6">
            <div>
              <Label htmlFor="amount">Amount (PHP)</Label>
              <Input
                id="amount"
                type="number"
                min="1"
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>

            <div className="space-y-4">
              <Label>Select Cash In Method</Label>
              {cashInMethods.map((method) => (
                <div
                  key={method.id}
                  className={`flex items-center gap-4 rounded-lg border p-4 cursor-pointer ${
                    selectedMethod === method.id ? "border-blue-500 bg-blue-50" : ""
                  }`}
                  onClick={() => setSelectedMethod(method.id)}
                >
                  <div className="rounded-full bg-gray-100 p-3">
                    <method.icon className="h-6 w-6 text-gray-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium">{method.title}</h3>
                    <p className="text-sm text-gray-600">{method.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={loading || !selectedMethod}
            >
              {loading ? "Processing..." : "Continue"}
            </Button>
          </form>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

