"use client"

import { useState, useEffect } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Navigation } from 'lucide-react'

export default function GPSPage() {
  const [location, setLocation] = useState({ latitude: 0, longitude: 0 })
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          })
        },
        (error) => {
          setError("Unable to retrieve your location")
        }
      )
    } else {
      setError("Geolocation is not supported by your browser")
    }
  }, [])

  const formatCoordinate = (coordinate: number, isLatitude: boolean) => {
    const absolute = Math.abs(coordinate)
    const degrees = Math.floor(absolute)
    const minutes = Math.floor((absolute - degrees) * 60)
    const seconds = ((absolute - degrees - minutes / 60) * 3600).toFixed(2)
    const direction = isLatitude
      ? coordinate >= 0 ? "N" : "S"
      : coordinate >= 0 ? "E" : "W"
    return `${degrees}° ${minutes}' ${seconds}" ${direction}`
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold">GPS Navigation</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Current Position</CardTitle>
          </CardHeader>
          <CardContent>
            {error ? (
              <p className="text-red-500">{error}</p>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-blue-500" />
                  <span>Latitude: {formatCoordinate(location.latitude, true)}</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-blue-500" />
                  <span>Longitude: {formatCoordinate(location.longitude, false)}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Navigation Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span>Speed:</span>
              <span>N/A</span>
            </div>
            <div className="flex items-center justify-between mt-2">
              <span>Heading:</span>
              <span>N/A</span>
            </div>
            <div className="flex items-center justify-between mt-2">
              <span>Altitude:</span>
              <span>N/A</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

