"use client"

import { useState, useEffect } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Compass } from 'lucide-react'

export default function CompassPage() {
  const [heading, setHeading] = useState(0)

  useEffect(() => {
    if ('deviceorientationabsolute' in window) {
      window.addEventListener('deviceorientationabsolute', handleOrientation)
    } else if ('deviceorientation' in window) {
      window.addEventListener('deviceorientation', handleOrientation)
    }

    return () => {
      window.removeEventListener('deviceorientationabsolute', handleOrientation)
      window.removeEventListener('deviceorientation', handleOrientation)
    }
  }, [])

  const handleOrientation = (event: DeviceOrientationEvent) => {
    let direction = event.alpha ?? 0
    setHeading(Math.round(direction))
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold">Digital Compass</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Current Heading</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <Compass className="h-32 w-32 text-blue-600" style={{ transform: `rotate(${heading}deg)` }} />
            <p className="text-4xl font-bold mt-4">{heading}°</p>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

