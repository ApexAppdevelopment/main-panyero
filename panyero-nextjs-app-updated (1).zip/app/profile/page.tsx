import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { User, Settings, CreditCard, HelpCircle, LogOut } from 'lucide-react'

const profileOptions = [
  { icon: User, title: "Personal Information", href: "/profile/personal" },
  { icon: CreditCard, title: "Payment Methods", href: "/profile/payment" },
  { icon: Settings, title: "Settings", href: "/profile/settings" },
  { icon: HelpCircle, title: "Help & Support", href: "/profile/help" },
]

export default function ProfilePage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Profile</h1>
        <div className="space-y-4">
          {profileOptions.map((option, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <a href={option.href} className="flex items-center">
                  <option.icon className="h-6 w-6 mr-4 text-purple-600" />
                  <span className="font-medium">{option.title}</span>
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
        <Button variant="outline" className="w-full flex items-center justify-center">
          <LogOut className="h-5 w-5 mr-2" />
          Sign Out
        </Button>
      </div>
      <BottomNav />
    </main>
  )
}

