import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { ShoppingCart } from 'lucide-react'

export default function CargoPlannerPage() {
  return <PlaceholderServicePage title="Cargo Planner" icon={ShoppingCart} />
}

