import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Radio } from 'lucide-react'

export default function AISPage() {
  return <PlaceholderServicePage title="AIS" icon={Radio} />
}

