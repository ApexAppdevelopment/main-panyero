import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Settings, User, CreditCard, HelpCircle, LogOut } from 'lucide-react'
import Link from "next/link"
import { useAuth } from "@/contexts/auth-context"

const menuItems = [
  { icon: User, title: "Profile", href: "/profile" },
  { icon: CreditCard, title: "Payment Methods", href: "/payment-methods" },
  { icon: Settings, title: "Settings", href: "/settings" },
  { icon: HelpCircle, title: "Help & Support", href: "/help" },
]

export default function MorePage() {
  const { signOut } = useAuth()

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">More</h1>
        
        <div className="space-y-4">
          {menuItems.map((item) => (
            <Card key={item.title}>
              <CardContent className="p-4">
                <Link href={item.href} className="flex items-center">
                  <item.icon className="h-6 w-6 mr-4 text-gray-500" />
                  <span className="font-medium">{item.title}</span>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <Button 
          variant="outline" 
          className="w-full flex items-center justify-center" 
          onClick={() => signOut()}
        >
          <LogOut className="h-5 w-5 mr-2" />
          Sign Out
        </Button>
      </div>

      <BottomNav />
    </main>
  )
}

