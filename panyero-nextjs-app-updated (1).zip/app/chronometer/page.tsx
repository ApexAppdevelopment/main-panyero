import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Watch } from 'lucide-react'

export default function ChronometerPage() {
  return <PlaceholderServicePage title="Chronometer" icon={Watch} />
}

