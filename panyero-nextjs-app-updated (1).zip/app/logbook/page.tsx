import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Book } from 'lucide-react'

export default function LogbookPage() {
  return <PlaceholderServicePage title="Logbook" icon={Book} />
}

