import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { HeartPulse } from 'lucide-react'

export default function HealthInsurancePage() {
  return <PlaceholderServicePage title="Health Insurance" icon={HeartPulse} />
}

