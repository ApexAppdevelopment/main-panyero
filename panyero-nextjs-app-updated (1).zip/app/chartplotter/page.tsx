import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Map } from 'lucide-react'

export default function ChartplotterPage() {
  return <PlaceholderServicePage title="Chartplotter" icon={Map} />
}

