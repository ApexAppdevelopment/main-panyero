import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Library } from 'lucide-react'

export default function MaritimeLibraryPage() {
  return <PlaceholderServicePage title="Maritime Library" icon={Library} />
}

