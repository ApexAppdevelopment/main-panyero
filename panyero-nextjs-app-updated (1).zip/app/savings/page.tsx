import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { PiggyBank } from 'lucide-react'

export default function SavingsPage() {
  return <PlaceholderServicePage title="Savings" icon={PiggyBank} />
}

