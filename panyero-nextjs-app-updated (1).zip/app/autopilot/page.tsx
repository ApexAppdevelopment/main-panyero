import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { PlaneLanding } from 'lucide-react'

export default function AutopilotPage() {
  return <PlaceholderServicePage title="Autopilot" icon={PlaneLanding} />
}

