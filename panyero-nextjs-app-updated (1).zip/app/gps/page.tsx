import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Satellite } from 'lucide-react'

export default function GPSPage() {
  return <PlaceholderServicePage title="GPS" icon={Satellite} />
}

