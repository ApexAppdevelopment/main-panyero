import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { QrCode } from 'lucide-react'

export default function ScanPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      <div className="flex flex-col items-center justify-center h-[calc(100vh-120px)]">
        <QrCode className="w-24 h-24 text-purple-600 mb-4" />
        <h1 className="text-2xl font-bold mb-4">Scan QR Code</h1>
        <Button>Open Camera</Button>
      </div>
      <BottomNav />
    </main>
  )
}

