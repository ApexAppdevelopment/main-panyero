"use client"

import Wallet from './wallet/page';
import Profile from './profile/page';
import Send_money from './send-money/page';
import Navigation from './navigation/page';
import Ai from './ai/page';
import Lottery from './lottery/page';
import Booking from './booking/page';
import Games from './games/page';
import Safety from './safety/page';
import Review_center from './review-center/page';
import Cash_in from './cash-in/page';
import Cash_out from './cash-out/page';
import Pay_bills from './pay-bills/page';
import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowDownToLine, Receipt, Users, MoreHorizontal } from 'lucide-react'
import { ServiceGrid } from "@/components/service-grid"
import { TransactionList } from "@/components/transaction-list"
import { BalanceCard } from "@/components/balance-card"
import { BillsList } from "@/components/bills-list"
import { SavingsPlans } from "@/components/savings-plans"
import { NewsList } from "@/components/news-list"
import { Circle, SmartphoneIcon as SimCard, Apple, Bolt } from 'lucide-react'


const services = [
  { icon: "zap", label: "Electricity", href: "/electricity" },
  { icon: "droplet", label: "Water", href: "/water" },
  { icon: "wifi", label: "Internet", href: "/internet" },
  { icon: "tv", label: "Television", href: "/television" },
  { icon: "trending-up", label: "Investment", href: "/investment" },
  { icon: "smartphone", label: "Mobile", href: "/mobile" },
  { icon: "plus-square", label: "Medical", href: "/medical" },
  { icon: "more-horizontal", label: "Other", href: "/other" },
]

const quickActions = [
  { icon: ArrowDownToLine, label: "Transfer", href: "/transfer" },
  { icon: Receipt, label: "Bill", href: "/bill" },
  { icon: Users, label: "Request", href: "/request" },
  { icon: MoreHorizontal, label: "More", href: "/more" },
]

const bills = [
  { icon: Circle, name: "Airtel", amount: 69.49 },
  { icon: Apple, name: "Apple", amount: 49.85 },
  { icon: SimCard, name: "TV", amount: 99.99 },
  { icon: Bolt, name: "Torrent", amount: 60.49 },
]

const savingsplans = [
  { icon: "Car", name: "New Car", amountLeft: 2000, progress: 60 },
  { icon: "Home", name: "Grand Home", amountLeft: 2000, progress: 30 },
]

const news = [
  {
    image: "/placeholder.svg?height=100&width=100",
    title: "Save and invest to obtain more",
    date: "13 May, 23",
    author: "Smith",
  },
  {
    image: "/placeholder.svg?height=100&width=100",
    title: "How to get more money from savings",
    date: "10 May, 23",
    author: "Laila",
  },
  {
    image: "/placeholder.svg?height=100&width=100",
    title: "5 Tips on expand your business",
    date: "6 May, 23",
    author: "Brunt",
  },
]

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("wallet")

  return (
    <main className="min-h-screen bg-gray-50">
      <StickyHeader />
      
      <div className="p-4 space-y-6 pb-24">
        <Tabs defaultValue="wallet" className="w-full overflow-x-auto">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="wallet">Wallet</TabsTrigger>
            <TabsTrigger value="savings">Savings</TabsTrigger>
            <TabsTrigger value="credit">Credit</TabsTrigger>
            <TabsTrigger value="loans">Loans</TabsTrigger>
          </TabsList>
        </Tabs>

        <BalanceCard 
          balance={106786.65}
          income={15256.33}
          expense={91530.32}
        />

        <div className="grid grid-cols-4 gap-4">
          {quickActions.map((action) => (
            <Button
              key={action.label}
              variant="outline"
              className="flex flex-col items-center justify-center h-20 bg-white"
              asChild
            >
              <a href={action.href}>
                <action.icon className="h-6 w-6 mb-1" />
                <span className="text-xs">{action.label}</span>
              </a>
            </Button>
          ))}
        </div>

        <BillsList bills={bills} />

        <SavingsPlans plans={savingsplans} />

        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold">Select service</h2>
            <a href="/services" className="text-purple-600 text-sm">
              See all
            </a>
          </div>
          <ServiceGrid services={services} />
        </div>

        <TransactionList />

        <NewsList news={news} />
      </div>

      <BottomNav />
    </main>
  )
}



<nav><ul><li><a href='/wallet'>Wallet</a></li>
<li><a href='/profile'>Profile</a></li>
<li><a href='/send-money'>Send_money</a></li>
<li><a href='/navigation'>Navigation</a></li>
<li><a href='/ai'>Ai</a></li>
<li><a href='/lottery'>Lottery</a></li>
<li><a href='/booking'>Booking</a></li>
<li><a href='/games'>Games</a></li>
<li><a href='/safety'>Safety</a></li>
<li><a href='/review-center'>Review_center</a></li>
<li><a href='/cash-in'>Cash_in</a></li>
<li><a href='/cash-out'>Cash_out</a></li>
<li><a href='/pay-bills'>Pay_bills</a></li>
</ul></nav>