"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Upload, Download, Trash2 } from 'lucide-react'
import { toast } from "sonner"

interface SafetyDocument {
  id: string
  name: string
  uploadDate: string
}

export default function SafetyDocumentsPage() {
  const [documents, setDocuments] = useState<SafetyDocument[]>([
    { id: "1", name: "Emergency Procedures.pdf", uploadDate: "2023-05-15" },
    { id: "2", name: "Safety Equipment Manual.pdf", uploadDate: "2023-06-01" },
  ])
  const [newDocument, setNewDocument] = useState<File | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setNewDocument(e.target.files[0])
    }
  }

  const uploadDocument = () => {
    if (newDocument) {
      const newDoc: SafetyDocument = {
        id: Date.now().toString(),
        name: newDocument.name,
        uploadDate: new Date().toISOString().split('T')[0],
      }
      setDocuments([...documents, newDoc])
      setNewDocument(null)
      toast.success("Document uploaded successfully")
    } else {
      toast.error("Please select a file to upload")
    }
  }

  const removeDocument = (id: string) => {
    setDocuments(documents.filter(doc => doc.id !== id))
    toast.success("Document removed")
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Safety Documents</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Upload New Document</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="document">Select Document</Label>
                <Input
                  id="document"
                  type="file"
                  onChange={handleFileChange}
                  accept=".pdf,.doc,.docx"
                />
              </div>
              <Button onClick={uploadDocument} className="w-full">
                <Upload className="mr-2 h-4 w-4" /> Upload Document
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Safety Documents List</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {documents.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-2 bg-white rounded-lg shadow">
                  <div className="flex items-center">
                    <FileText className="h-6 w-6 mr-2 text-blue-500" />
                    <div>
                      <p className="font-semibold">{doc.name}</p>
                      <p className="text-sm text-gray-500">Uploaded: {doc.uploadDate}</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="icon" onClick={() => {
                      // In a real app, this would download the document
                      toast.info(`Downloading ${doc.name}...`)
                    }}>
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={() => removeDocument(doc.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

