import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, FileText, CheckSquare, Calendar } from 'lucide-react'
import Link from "next/link"

const safetyItems = [
  { icon: AlertTriangle, title: "Emergency Contacts", href: "/safety/emergency-contacts" },
  { icon: FileText, title: "Safety Documents", href: "/safety/documents" },
  { icon: CheckSquare, title: "Equipment Checklist", href: "/safety/equipment-checklist" },
  { icon: Calendar, title: "Safety Inspections", href: "/safety/inspections" },
]

export default function SafetyPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Safety Center</h1>
        
        <div className="grid gap-4 md:grid-cols-2">
          {safetyItems.map((item) => (
            <Card key={item.title}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <item.icon className="mr-2 h-5 w-5 text-primary" />
                  {item.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button asChild className="w-full">
                  <Link href={item.href}>View</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

