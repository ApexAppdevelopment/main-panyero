"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Phone, Plus, Trash2 } from 'lucide-react'
import { toast } from "sonner"

interface EmergencyContact {
  id: string
  name: string
  number: string
}

export default function EmergencyContactsPage() {
  const [contacts, setContacts] = useState<EmergencyContact[]>([
    { id: "1", name: "Coast Guard", number: "+1234567890" },
    { id: "2", name: "Ship's Doctor", number: "+0987654321" },
  ])
  const [newName, setNewName] = useState("")
  const [newNumber, setNewNumber] = useState("")

  const addContact = () => {
    if (newName && newNumber) {
      const newContact: EmergencyContact = {
        id: Date.now().toString(),
        name: newName,
        number: newNumber,
      }
      setContacts([...contacts, newContact])
      setNewName("")
      setNewNumber("")
      toast.success("Emergency contact added successfully")
    } else {
      toast.error("Please enter both name and number")
    }
  }

  const removeContact = (id: string) => {
    setContacts(contacts.filter(contact => contact.id !== id))
    toast.success("Emergency contact removed")
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Emergency Contacts</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Add New Contact</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Enter contact name"
                />
              </div>
              <div>
                <Label htmlFor="number">Number</Label>
                <Input
                  id="number"
                  value={newNumber}
                  onChange={(e) => setNewNumber(e.target.value)}
                  placeholder="Enter contact number"
                />
              </div>
              <Button onClick={addContact} className="w-full">
                <Plus className="mr-2 h-4 w-4" /> Add Contact
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Emergency Contacts List</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {contacts.map((contact) => (
                <div key={contact.id} className="flex items-center justify-between p-2 bg-white rounded-lg shadow">
                  <div>
                    <p className="font-semibold">{contact.name}</p>
                    <p className="text-sm text-gray-500">{contact.number}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="icon" onClick={() => {
                      // In a real app, this would initiate a phone call
                      toast.info(`Calling ${contact.name}...`)
                    }}>
                      <Phone className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={() => removeContact(contact.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

