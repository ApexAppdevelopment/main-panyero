"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MessageSquare } from 'lucide-react'
import { toast } from "sonner"

export default function ChatbotPage() {
  const [message, setMessage] = useState("")
  const [conversation, setConversation] = useState<{role: string, content: string}[]>([])
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch("/api/ai/chatbot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      })
      const data = await response.json()
      if (response.ok) {
        setConversation([...conversation, {role: "user", content: message}, {role: "assistant", content: data.reply}])
        setMessage("")
      } else {
        throw new Error(data.error || "Something went wrong")
      }
    } catch (error) {
      toast.error("Failed to get response")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold flex items-center">
          <MessageSquare className="mr-2 h-6 w-6" />
          AI Chatbot
        </h1>
        
        <div className="bg-white rounded-lg shadow p-4 h-[60vh] overflow-y-auto">
          {conversation.map((msg, index) => (
            <div key={index} className={`mb-4 ${msg.role === "user" ? "text-right" : "text-left"}`}>
              <span className={`inline-block p-2 rounded-lg ${msg.role === "user" ? "bg-blue-100" : "bg-gray-100"}`}>
                {msg.content}
              </span>
            </div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="flex space-x-2">
          <Input
            placeholder="Type your message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            required
          />
          <Button type="submit" disabled={loading}>
            {loading ? "Sending..." : "Send"}
          </Button>
        </form>
      </div>

      <BottomNav />
    </main>
  )
}

