import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { FileText } from 'lucide-react'

export default function TextGenerationPage() {
  return <PlaceholderServicePage title="AI Text Generation" icon={FileText} />
}

