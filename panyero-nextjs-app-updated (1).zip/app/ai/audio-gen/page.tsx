import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { FileAudio } from 'lucide-react'

export default function AudioGenerationPage() {
  return <PlaceholderServicePage title="AI Audio Generation" icon={FileAudio} />
}

