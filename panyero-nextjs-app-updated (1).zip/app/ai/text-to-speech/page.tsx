"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Mic } from 'lucide-react'
import { toast } from "sonner"

export default function TextToSpeechPage() {
  const [text, setText] = useState("")
  const [voice, setVoice] = useState("en-US-Standard-A")
  const [audioUrl, setAudioUrl] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch("/api/ai/text-to-speech", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voice }),
      })
      if (response.ok) {
        const blob = await response.blob()
        const url = URL.createObjectURL(blob)
        setAudioUrl(url)
      } else {
        throw new Error("Failed to generate speech")
      }
    } catch (error) {
      toast.error("Failed to generate speech")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold flex items-center">
          <Mic className="mr-2 h-6 w-6" />
          AI Text-to-Speech
        </h1>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            placeholder="Enter text to convert to speech"
            value={text}
            onChange={(e) => setText(e.target.value)}
            required
          />
          <Select value={voice} onValueChange={setVoice}>
            <SelectTrigger>
              <SelectValue placeholder="Select a voice" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en-US-Standard-A">US English (Female)</SelectItem>
              <SelectItem value="en-US-Standard-B">US English (Male)</SelectItem>
              <SelectItem value="en-GB-Standard-A">British English (Female)</SelectItem>
              <SelectItem value="en-GB-Standard-B">British English (Male)</SelectItem>
            </SelectContent>
          </Select>
          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Generating..." : "Generate Speech"}
          </Button>
        </form>

        {audioUrl && (
          <div className="mt-6">
            <h2 className="text-lg font-semibold mb-2">Generated Speech:</h2>
            <audio controls src={audioUrl} className="w-full" />
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

