import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Zap } from 'lucide-react'

export default function ElectricityBillPage() {
  return <PlaceholderServicePage title="Electricity Bill" icon={Zap} />
}

