"use server"

import { revalidatePath } from "next/cache"
import { createTransaction, updateWalletBalance, getWallet } from "@/lib/wallet-service"

export async function sendMoney(
  fromUserId: string,
  toUserId: string,
  amount: number,
  description: string
) {
  try {
    const senderWallet = await getWallet(fromUserId)
    const receiverWallet = await getWallet(toUserId)

    if (!senderWallet || !receiverWallet) {
      throw new Error('Wallet not found')
    }

    // Debit from sender's wallet
    await updateWalletBalance(senderWallet.id, amount, 'debit')
    
    // Create transaction record for sender
    await createTransaction(
      fromUserId,
      'send',
      -amount,
      'PHP',
      `Sent to ${description}`
    )

    // Credit to receiver's wallet
    await updateWalletBalance(receiverWallet.id, amount, 'credit')
    
    // Create transaction record for receiver
    await createTransaction(
      toUserId,
      'receive',
      amount,
      'PHP',
      `Received from ${description}`
    )

    revalidatePath('/')
    return { success: true }
  } catch (error) {
    console.error('Error sending money:', error)
    return { success: false, error: 'Failed to send money' }
  }
}

export async function cashIn(
  userId: string,
  amount: number,
  method: string
) {
  try {
    const wallet = await getWallet(userId)
    if (!wallet) {
      throw new Error('Wallet not found')
    }

    // Credit to user's wallet
    await updateWalletBalance(wallet.id, amount, 'credit')
    
    // Create transaction record
    await createTransaction(
      userId,
      'cash_in',
      amount,
      'PHP',
      `Cash in via ${method}`
    )

    revalidatePath('/')
    return { success: true }
  } catch (error) {
    console.error('Error cashing in:', error)
    return { success: false, error: 'Failed to cash in' }
  }
}

export async function cashOut(
  userId: string,
  amount: number,
  method: string
) {
  try {
    const wallet = await getWallet(userId)
    if (!wallet) {
      throw new Error('Wallet not found')
    }

    // Debit from user's wallet
    await updateWalletBalance(wallet.id, amount, 'debit')
    
    // Create transaction record
    await createTransaction(
      userId,
      'cash_out',
      -amount,
      'PHP',
      `Cash out via ${method}`
    )

    revalidatePath('/')
    return { success: true }
  } catch (error) {
    console.error('Error cashing out:', error)
    return { success: false, error: 'Failed to cash out' }
  }
}

