import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Leaf } from "lucide-react"

export default function GreenProductsPage() {
  return <PlaceholderServicePage title="Green Products" icon={Leaf} />
}

