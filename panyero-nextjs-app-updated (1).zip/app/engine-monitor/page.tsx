import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Gauge } from 'lucide-react'

export default function EngineMonitorPage() {
  return <PlaceholderServicePage title="Engine Monitor" icon={Gauge} />
}

