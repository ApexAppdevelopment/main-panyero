import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Recycle } from 'lucide-react'

export default function RecyclingPage() {
  return <PlaceholderServicePage title="Recycling" icon={Recycle} />
}

