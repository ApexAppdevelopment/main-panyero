"use client"

import { Bell } from 'lucide-react'
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function StickyHeader() {
  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b">
      <div className="flex items-center justify-between px-4 py-2">
        <Link href="/" className="flex items-center gap-2">
          <Image
            src="/logo.png"
            alt="Panyero"
            width={32}
            height={32}
            className="w-8 h-8"
          />
          <span className="font-semibold">Panyero</span>
        </Link>
        <Button variant="ghost" size="icon" asChild>
          <Link href="/notifications">
            <Bell className="h-5 w-5" />
            <span className="sr-only">Notifications</span>
          </Link>
        </Button>
      </div>
    </header>
  )
}

