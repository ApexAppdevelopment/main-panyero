"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { CreditCard, Wallet, QrCode, BarChart2, User } from 'lucide-react'

const navItems = [
  { icon: Wallet, label: "Panyero", href: "/" },
  { icon: CreditCard, label: "Eservices", href: "/eservices" },
  { icon: QrCode, label: "", href: "/scan", isMain: true },
  { icon: BarChart2, label: "Maritime", href: "/maritime" },
  { icon: User, label: "Profile", href: "/profile" },
]

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t">
      <div className="flex items-center justify-around px-2 py-1">
        {navItems.map((item) => {
          const Icon = item.icon
          const isMain = item.isMain
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center p-2 transition-all duration-200",
                isMain ? "-mt-4" : "",
                pathname === item.href ? "text-purple-600" : "text-gray-600"
              )}
            >
              <div className={cn(
                "relative",
                isMain ? "p-4 bg-purple-600 rounded-full" : ""
              )}>
                <Icon className={cn(
                  "h-6 w-6",
                  isMain ? "text-white" : ""
                )} />
              </div>
              {!isMain && (
                <span className="text-[10px] mt-1">{item.label}</span>
              )}
            </Link>
          )
        })}
      </div>
    </nav>
  )
}

