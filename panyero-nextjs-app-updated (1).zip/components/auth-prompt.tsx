import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export function AuthPrompt() {
  return (
    <Card className="mt-4">
      <CardHeader>
        <CardTitle>Login Required</CardTitle>
        <CardDescription>You need to be logged in to view and place bets</CardDescription>
      </CardHeader>
      <CardContent className="flex justify-center space-x-4">
        <Button asChild>
          <Link href="/auth/sign-in">Login</Link>
        </Button>
        <Button asChild variant="outline">
          <Link href="/auth/sign-up">Sign Up</Link>
        </Button>
      </CardContent>
    </Card>
  )
}

