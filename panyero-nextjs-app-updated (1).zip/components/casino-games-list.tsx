"use client"

import { useState } from 'react'
import { fetchCasinoGames, CasinoGame } from "@/lib/casino-service"
import { placeBet } from "@/lib/wallet-service"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Flame, Sparkles, Users } from 'lucide-react'
import Image from "next/image"
import { toast } from "sonner"

export function CasinoGamesList() {
  const { user } = useAuth()
  const [games, setGames] = useState<CasinoGame[]>([])
  const [loading, setLoading] = useState(true)
  const [betAmounts, setBetAmounts] = useState<{ [key: string]: string }>({})

  useEffect(() => {
    const loadGames = async () => {
      const fetchedGames = await fetchCasinoGames()
      setGames(fetchedGames)
      setLoading(false)
    }
    loadGames()
  }, [])

  const handleBetAmountChange = (gameId: string, amount: string) => {
    setBetAmounts(prev => ({ ...prev, [gameId]: amount }))
  }

  const handlePlaceBet = async (game: CasinoGame) => {
    if (!user) {
      toast.error("Please sign in to place a bet")
      return
    }

    const betAmount = parseFloat(betAmounts[game.id] || "0")
    if (isNaN(betAmount) || betAmount <= 0) {
      toast.error("Please enter a valid bet amount")
      return
    }

    const result = await placeBet(user.id, game.id, betAmount)
    if (result.success) {
      toast.success(`Bet of ₱${betAmount} placed on ${game.name}`)
      // You might want to update the user's balance in the UI here
    } else {
      toast.error(result.error || "Failed to place bet")
    }
  }

  if (loading) {
    return <CasinoGamesLoading />
  }

  if (!games.length) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-500">No games available at the moment</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {games.map((game) => (
        <Card key={game.id} className="overflow-hidden">
          <div className="relative h-48 w-full">
            <Image
              src={game.thumbnail}
              alt={game.name}
              fill
              className="object-cover"
            />
            <div className="absolute top-2 right-2 flex gap-2">
              {game.isNew && (
                <Badge variant="secondary">
                  <Sparkles className="h-3 w-3 mr-1" />
                  New
                </Badge>
              )}
              {game.isHot && (
                <Badge variant="destructive">
                  <Flame className="h-3 w-3 mr-1" />
                  Hot
                </Badge>
              )}
            </div>
          </div>
          <CardHeader>
            <CardTitle className="flex justify-between items-center">
              <span>{game.name}</span>
              <Badge variant="outline" className="ml-2">
                {game.type}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-500 mb-4">{game.description}</p>
            <div className="flex items-center text-sm text-gray-500 mb-4">
              <Users className="h-4 w-4 mr-1" />
              {game.popularity} players
            </div>
            <div className="flex items-center space-x-2">
              <Input
                type="number"
                placeholder="Bet amount"
                value={betAmounts[game.id] || ""}
                onChange={(e) => handleBetAmountChange(game.id, e.target.value)}
                className="w-24"
              />
              <Button onClick={() => handlePlaceBet(game)}>Place Bet</Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

