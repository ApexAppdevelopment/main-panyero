"use client"

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Wallet, Compass, LifeBuoy, Menu } from 'lucide-react'

const navItems = [
  { icon: Wallet, label: "Wallet", href: "/wallet" },
  { icon: Compass, label: "Navigation", href: "/navigation" },
  { icon: LifeBuoy, label: "Safety", href: "/safety" },
  { icon: Menu, label: "More", href: "/more" },
]

export function LoggedInView() {
  return (
    <motion.div
      className="flex flex-col items-center justify-center min-h-screen w-full"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.5 }}
    >
      <h1 className="text-4xl font-bold text-white mb-8">Welcome back, Seafarer!</h1>
      <div className="grid grid-cols-2 gap-4 w-full max-w-md">
        {navItems.map((item) => (
          <Button key={item.href} asChild variant="outline" className="h-24 bg-white bg-opacity-20 backdrop-blur-lg hover:bg-opacity-30 transition-all duration-300">
            <Link href={item.href} className="flex flex-col items-center justify-center">
              <item.icon className="h-8 w-8 mb-2" />
              <span>{item.label}</span>
            </Link>
          </Button>
        ))}
      </div>
    </motion.div>
  )
}

