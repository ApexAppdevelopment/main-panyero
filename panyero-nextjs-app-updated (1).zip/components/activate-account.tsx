"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "sonner"
import { updateWalletBalance, createTransaction, updateUserStatus } from "@/lib/wallet-service"

export function ActivateAccount() {
  const { user } = useAuth()
  const [amount, setAmount] = useState("100")
  const [loading, setLoading] = useState(false)

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    try {
      setLoading(true)
      const numAmount = Number(amount)
      
      if (numAmount < 100) {
        toast.error("Minimum activation amount is ₱100")
        return
      }

      await updateWalletBalance(user.id, numAmount, 'credit')
      await createTransaction(
        user.id,
        'cash_in',
        numAmount,
        'PHP',
        'Account activation'
      )

      // Update user status to active
      await updateUserStatus(user.id, 'active')

      toast.success("Account activated successfully!")
    } catch (error) {
      console.error("Error activating account:", error)
      toast.error("Failed to activate account")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Activate Your Account</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleActivate}>
          <div className="space-y-4">
            <div>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                min="100"
                step="1"
                required
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Activating..." : "Activate Account (Min ₱100)"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

