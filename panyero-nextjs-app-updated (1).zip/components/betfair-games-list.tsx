"use client"

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import { useAuth } from "@/contexts/auth-context"
import { getWallet, updateWalletBalance } from "@/lib/wallet-service"

interface Game {
  id: string
  name: string
  odds: number
  bannerImage: string
}

export function BetfairGamesList() {
  const [games, setGames] = useState<Game[]>([])
  const [loading, setLoading] = useState(true)
  const [betAmounts, setBetAmounts] = useState<{ [key: string]: string }>({})
  const { user } = useAuth()
  const [walletBalance, setWalletBalance] = useState(0)

  useEffect(() => {
    fetchGames()
    if (user) {
      fetchWalletBalance()
    }
  }, [user])

  const fetchGames = async () => {
    try {
      const response = await fetch('/api/betfair')
      if (!response.ok) {
        throw new Error('Failed to fetch games')
      }
      const data = await response.json()
      const formattedGames = data.markets.map((market: any) => ({
        id: market.marketId,
        name: market.marketName,
        odds: market.runners[0].price,
        bannerImage: `/placeholder.svg?height=200&width=400&text=${encodeURIComponent(market.marketName)}`
      }))
      setGames(formattedGames)
    } catch (error) {
      console.error('Error fetching games:', error)
      toast.error('Failed to load games')
    } finally {
      setLoading(false)
    }
  }

  const fetchWalletBalance = async () => {
    if (user) {
      const wallet = await getWallet(user.id)
      if (wallet) {
        setWalletBalance(wallet.balance)
      }
    }
  }

  const handleBetAmountChange = (gameId: string, amount: string) => {
    setBetAmounts(prev => ({ ...prev, [gameId]: amount }))
  }

  const handlePlaceBet = async (game: Game) => {
    if (!user) {
      toast.error("Please log in to place a bet")
      return
    }

    const betAmount = parseFloat(betAmounts[game.id] || "0")
    if (isNaN(betAmount) ||betAmount <= 0) {
      toast.error("Please enter a valid bet amount")
      return
    }

    try {
      const response = await fetch('/api/betting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gameId: game.id,
          outcome: game.name,
          amount: betAmount,
          odds: game.odds
        }),
      })

      const result = await response.json()

      if (result.success) {
        toast.success(result.message)
        setWalletBalance(result.newBalance)
        // Update wallet balance with win amount if applicable
        if (result.winAmount) {
          setWalletBalance(prevBalance => prevBalance + result.winAmount);
          toast.success(`You won ${formatCurrency(result.winAmount)}!`);
        }
        setBetAmounts(prev => ({ ...prev, [game.id]: "" }))
      } else {
        toast.error(result.error || "Failed to place bet")
      }
    } catch (error) {
      console.error('Error placing bet:', error)
      toast.error("Failed to place bet")
    }
  }

  const formatCurrency = (amount: number): string => {
    return amount.toFixed(2);
  }

  if (loading) {
    return <div>Loading games...</div>
  }

  return (
    <div className="space-y-4">
      <div className="text-xl font-bold mb-4">Your Wallet Balance: ${walletBalance.toFixed(2)}</div>
      {games.map((game) => (
        <Card key={game.id}>
          <CardHeader>
            <CardTitle>{game.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <Image src={game.bannerImage} alt={game.name} width={400} height={200} className="mb-4 rounded-lg" />
            <p className="mb-2">Odds: {game.odds}</p>
            <div className="flex items-center space-x-2">
              <Input
                type="number"
                placeholder="Bet amount"
                value={betAmounts[game.id] || ""}
                onChange={(e) => handleBetAmountChange(game.id, e.target.value)}
                className="w-24"
              />
              <Button 
                onClick={() => handlePlaceBet(game)}
                disabled={!user}
              >
                Place Bet
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

