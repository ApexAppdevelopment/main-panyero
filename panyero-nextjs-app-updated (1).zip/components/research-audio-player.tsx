"use client"

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Play, Pause, SkipForward, SkipBack } from 'lucide-react'
import { toast } from "sonner"

export function ResearchAudioPlayer() {
  const [query, setQuery] = useState('')
  const [audioUrls, setAudioUrls] = useState<string[]>([])
  const [currentAudioIndex, setCurrentAudioIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [audio, setAudio] = useState<HTMLAudioElement | null>(null)
  const [loading, setLoading] = useState(false)

  const handleSearch = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/research-audio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      })
      const data = await response.json()
      if (response.ok) {
        setAudioUrls(data.audioUrls)
        toast.success('Research audio generated successfully')
      } else {
        throw new Error(data.error || 'Failed to generate research audio')
      }
    } catch (error) {
      console.error(error)
      toast.error('Failed to generate research audio')
    } finally {
      setLoading(false)
    }
  }

  const playAudio = (index: number) => {
    if (audio) {
      audio.pause()
    }
    const newAudio = new Audio(audioUrls[index])
    newAudio.play()
    setAudio(newAudio)
    setIsPlaying(true)
    setCurrentAudioIndex(index)
  }

  const togglePlayPause = () => {
    if (audio) {
      if (isPlaying) {
        audio.pause()
      } else {
        audio.play()
      }
      setIsPlaying(!isPlaying)
    } else if (audioUrls.length > 0) {
      playAudio(0)
    }
  }

  const playNext = () => {
    if (currentAudioIndex < audioUrls.length - 1) {
      playAudio(currentAudioIndex + 1)
    }
  }

  const playPrevious = () => {
    if (currentAudioIndex > 0) {
      playAudio(currentAudioIndex - 1)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Research Audio Player</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex space-x-2">
          <Input
            placeholder="Enter research topic"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <Button onClick={handleSearch} disabled={loading}>
            {loading ? 'Searching...' : <Search className="h-4 w-4" />}
          </Button>
        </div>
        {audioUrls.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm text-muted-foreground">
              Playing chunk {currentAudioIndex + 1} of {audioUrls.length}
            </div>
            <div className="flex justify-center space-x-2">
              <Button onClick={playPrevious} disabled={currentAudioIndex === 0}>
                <SkipBack className="h-4 w-4" />
              </Button>
              <Button onClick={togglePlayPause}>
                {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
              <Button onClick={playNext} disabled={currentAudioIndex === audioUrls.length - 1}>
                <SkipForward className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

