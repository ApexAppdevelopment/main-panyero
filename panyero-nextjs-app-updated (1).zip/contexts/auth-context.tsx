"use client"

import { createContext, useContext, useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { addUser, getUser, updateUser, addWallet, getWallet, updateWallet, addTransaction } from '@/lib/indexeddb-service'

interface AuthContextType {
  user: { id: string; email: string; fullName: string; mobileNumber: string; referralId?: string; status: string; createdAt: Date } | null
  signUp: (email: string, password: string, fullName: string, mobileNumber: string, referralId: string) => Promise<void>
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  getProfile: () => Promise<any>
  updateUserProfile: (data: Partial<{ id: string; email: string; fullName: string; mobileNumber: string; referralId?: string; status: string; createdAt: Date }>) => Promise<void>
  applyReferral: (referrerId: string, newUserId: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType | null>(null)

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<{ id: string; email: string; fullName: string; mobileNumber: string; referralId?: string; status: string; createdAt: Date } | null>(null)
  const router = useRouter()

  useEffect(() => {
    const unsubscribe = () => {} //No need for firebase listener
    return () => unsubscribe()
  }, [])

  const applyReferral = async (referrerId: string, newUserId: string) => {
    try {
      const referrer = await getUser(referrerId);
      if (referrer && referrer.status === 'active') {
        const referrerWallet = await getWallet(referrerId);
        if (referrerWallet) {
          await updateWallet(referrerWallet.id, { balance: referrerWallet.balance + 50 });
          await addTransaction({
            id: Math.random().toString(36).substr(2, 9),
            userId: referrerId,
            type: 'referral_bonus',
            amount: 50,
            currency: 'PHP',
            description: `Referral bonus for user ${newUserId}`,
            createdAt: new Date(),
          });
          toast.success("Referral applied successfully!");
        }
      } else {
        toast.error("Referral not applied. Referrer's account is inactive.");
      }
    } catch (error) {
      console.error("Error applying referral:", error);
      toast.error("Failed to apply referral");
    }
  };

  const signUp = async (email: string, password: string, fullName: string, mobileNumber: string, referralId: string) => {
    try {
      const userId = Math.random().toString(36).substr(2, 9); // Generate a random ID
      const newUser = {
        id: userId,
        email,
        fullName,
        mobileNumber,
        referralId,
        status: 'inactive',
        createdAt: new Date(),
      };
      await addUser(newUser);

      // Create a wallet for the new user
      await addWallet({
        id: Math.random().toString(36).substr(2, 9),
        userId,
        balance: 0,
        currency: 'PHP',
        status: 'inactive',
      });

      if (referralId) {
        await applyReferral(referralId, userId);
      }

      setUser(newUser);
      toast.success('Account created successfully.');
      router.push('/cash-in');
    } catch (error) {
      console.error("Error during sign up:", error);
      toast.error('Failed to create account. Please try again.');
      throw error;
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const users = await getUser(email); // Assuming getUser retrieves by email
      if (users) {
        setUser(users);
        toast.success('Signed in successfully.');
        router.push('/');
      } else {
        throw new Error('User not found');
      }
    } catch (error) {
      console.error("Error during sign in:", error);
      toast.error('Failed to sign in. Please check your credentials.');
      throw error;
    }
  };

  const signOut = async () => {
    try {
      setUser(null);
      router.push('/auth/sign-in');
      toast.success('Signed out successfully');
    } catch (error) {
      console.error('Error during sign out:', error);
      toast.error('Failed to sign out');
      throw error;
    }
  };

  const getProfile = async () => {
    if (!user) return null;
    return getUser(user.id);
  };

  const updateUserProfile = async (data: Partial<{ id: string; email: string; fullName: string; mobileNumber: string; referralId?: string; status: string; createdAt: Date }>) => {
    if (!user) throw new Error('No user logged in');
    try {
      await updateUser(user.id, data);
      setUser(prevUser => ({ ...prevUser, ...data }));
    } catch (error) {
      console.error("Error updating user profile:", error);
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ user, signUp, signIn, signOut, getProfile, updateUserProfile, applyReferral }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

