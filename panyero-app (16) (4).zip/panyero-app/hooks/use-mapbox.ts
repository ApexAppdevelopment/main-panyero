import { useState, useEffect } from 'react'
import mapboxgl from 'mapbox-gl'

export const useMapbox = (accessToken: string) => {
  const [map, setMap] = useState<mapboxgl.Map | null>(null)
  const [viewport, setViewport] = useState({
    latitude: 0,
    longitude: 0,
    zoom: 2
  })

  useEffect(() => {
    mapboxgl.accessToken = accessToken

    const initializeMap = new mapboxgl.Map({
      container: 'map-container',
      style: 'mapbox://styles/mapbox/navigation-night-v1',
      center: [viewport.longitude, viewport.latitude],
      zoom: viewport.zoom
    })

    initializeMap.on('load', () => {
      setMap(initializeMap)
    })

    initializeMap.on('move', () => {
      const { lng, lat } = initializeMap.getCenter()
      setViewport({
        longitude: lng,
        latitude: lat,
        zoom: initializeMap.getZoom()
      })
    })

    return () => initializeMap.remove()
  }, [])

  return { map, viewport, setViewport }
}

