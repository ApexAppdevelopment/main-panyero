import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface PanyeroDBSchema extends DBSchema {
  users: {
    key: string;
    value: {
      id: string;
      email: string;
      fullName: string;
      mobileNumber: string;
      referralId: string;
      status: 'active' | 'inactive';
      createdAt: Date;
    };
  };
  wallets: {
    key: string;
    value: {
      id: string;
      userId: string;
      balance: number;
      currency: string;
      status: string;
    };
  };
  transactions: {
    key: string;
    value: {
      id: string;
      userId: string;
      type: string;
      amount: number;
      currency: string;
      description: string;
      createdAt: Date;
    };
    indexes: { 'by-user': string };
  };
}

const DB_NAME = 'PanyeroDB';
const DB_VERSION = 1;

async function openPanyeroDB(): Promise<IDBPDatabase<PanyeroDBSchema>> {
  return openDB<PanyeroDBSchema>(DB_NAME, DB_VERSION, {
    upgrade(db) {
      db.createObjectStore('users', { keyPath: 'id' });
      db.createObjectStore('wallets', { keyPath: 'id' });
      const transactionsStore = db.createObjectStore('transactions', { keyPath: 'id', autoIncrement: true });
      transactionsStore.createIndex('by-user', 'userId');
    },
  });
}

export async function addUser(user: PanyeroDBSchema['users']['value']): Promise<void> {
  const db = await openPanyeroDB();
  await db.put('users', user);
}

export async function getUser(id: string): Promise<PanyeroDBSchema['users']['value'] | undefined> {
  const db = await openPanyeroDB();
  return db.get('users', id);
}

export async function updateUser(id: string, updates: Partial<PanyeroDBSchema['users']['value']>): Promise<void> {
  const db = await openPanyeroDB();
  const user = await db.get('users', id);
  if (user) {
    await db.put('users', { ...user, ...updates });
  }
}

export async function addWallet(wallet: PanyeroDBSchema['wallets']['value']): Promise<void> {
  const db = await openPanyeroDB();
  await db.put('wallets', wallet);
}

export async function getWallet(userId: string): Promise<PanyeroDBSchema['wallets']['value'] | undefined> {
  const db = await openPanyeroDB();
  const wallets = await db.getAll('wallets');
  return wallets.find(wallet => wallet.userId === userId);
}

export async function updateWallet(id: string, updates: Partial<PanyeroDBSchema['wallets']['value']>): Promise<void> {
  const db = await openPanyeroDB();
  const wallet = await db.get('wallets', id);
  if (wallet) {
    await db.put('wallets', { ...wallet, ...updates });
  }
}

export async function addTransaction(transaction: PanyeroDBSchema['transactions']['value']): Promise<void> {
  const db = await openPanyeroDB();
  await db.add('transactions', transaction);
}

export async function getTransactions(userId: string, limit: number = 10): Promise<PanyeroDBSchema['transactions']['value'][]> {
  const db = await openPanyeroDB();
  const tx = db.transaction('transactions', 'readonly');
  const index = tx.store.index('by-user');
  return index.getAll(userId, limit);
}

