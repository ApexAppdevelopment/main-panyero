import { getWallet, updateWallet, addTransaction, getTransactions } from './indexeddb-service';

export interface Wallet {
  id: string;
  userId: string;
  balance: number;
  currency: string;
  status: string;
}

export interface Transaction {
  id: string;
  userId: string;
  type: string;
  amount: number;
  currency: string;
  description: string;
  createdAt: Date;
}

export async function getUserWallet(userId: string): Promise<Wallet | null> {
  const wallet = await getWallet(userId);
  return wallet || null;
}

export async function updateWalletBalance(
  userId: string,
  amount: number,
  type: 'credit' | 'debit'
): Promise<Wallet> {
  const wallet = await getWallet(userId);
  if (!wallet) {
    throw new Error('Wallet not found');
  }

  const newBalance = type === 'credit' ? wallet.balance + amount : wallet.balance - amount;

  if (type === 'debit' && newBalance < 0) {
    throw new Error('Insufficient funds');
  }

  await updateWallet(wallet.id, { balance: newBalance });

  return { ...wallet, balance: newBalance };
}

export async function createTransaction(
  userId: string,
  type: string,
  amount: number,
  currency: string,
  description: string
): Promise<Transaction> {
  const newTransaction = {
    id: Math.random().toString(36).substr(2, 9),
    userId,
    type,
    amount,
    currency,
    description,
    createdAt: new Date(),
  };
  await addTransaction(newTransaction);
  return newTransaction;
}

export async function getUserTransactions(
  userId: string,
  limitCount: number = 10
): Promise<Transaction[]> {
  return getTransactions(userId, limitCount);
}

export async function getUserStatus(userId: string): Promise<string> {
  const wallet = await getWallet(userId);
  return wallet ? wallet.status : 'inactive';
}

export async function updateUserStatus(userId: string, status: 'active' | 'inactive'): Promise<void> {
  const wallet = await getWallet(userId);
  if (wallet) {
    await updateWallet(wallet.id, { status });
  }
}

