"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Eye, EyeOff } from 'lucide-react'

interface BalanceCardProps {
  balance: number
  income: number
  expense: number
}

export function BalanceCard({ balance, income, expense }: BalanceCardProps) {
  const [showBalance, setShowBalance] = useState(true)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP'
    }).format(amount)
  }

  return (
    <Card className="p-6 bg-gradient-to-br from-purple-600 to-purple-700 text-white rounded-xl">
      <div className="flex justify-between items-start mb-8">
        <div>
          <p className="text-sm opacity-90 mb-2">Total Balance</p>
          <h1 className="text-3xl font-bold">
            {showBalance ? formatCurrency(balance) : '••••••••'}
          </h1>
        </div>
        <button
          onClick={() => setShowBalance(!showBalance)}
          className="p-2 hover:bg-white/10 rounded-full transition-colors"
        >
          {showBalance ? (
            <EyeOff className="h-5 w-5" />
          ) : (
            <Eye className="h-5 w-5" />
          )}
        </button>
      </div>
      <div className="flex justify-between text-sm">
        <div>
          <p className="opacity-90 mb-1">↓ Income</p>
          <p className="font-semibold">
            {showBalance ? formatCurrency(income) : '••••••'}
          </p>
        </div>
        <div className="text-right">
          <p className="opacity-90 mb-1">↑ Expense</p>
          <p className="font-semibold">
            {showBalance ? formatCurrency(expense) : '••••••'}
          </p>
        </div>
      </div>
    </Card>
  )
}

