"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TypeIcon as type, LucideIcon } from 'lucide-react'

interface Bill {
  icon: LucideIcon
  name: string
  amount: number
}

interface BillsListProps {
  bills: Bill[]
}

export function BillsList({ bills }: BillsListProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(amount)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Bills Detail
          <Button variant="link" size="sm">See all</Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-4">
          {bills.map((bill) => (
            <div key={bill.name} className="flex items-center justify-between border-b pb-3 last:border-b-0 last:pb-0">
              <div className="flex items-center gap-2">
                <bill.icon className="h-6 w-6 text-purple-600" />
                <div>
                  <p className="font-medium">{bill.name}</p>
                  <p className="text-sm text-muted-foreground">Pre-paid</p>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <p className="font-medium">{formatCurrency(bill.amount)}</p>
                <Button size="sm">Pay</Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

