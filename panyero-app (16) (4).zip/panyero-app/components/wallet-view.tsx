"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowDownLeft, ArrowUpRight } from 'lucide-react'
import Link from "next/link"
import { getUserWallet, getUserTransactions, Wallet, Transaction } from "@/lib/wallet-service"

export function WalletView() {
  const { user } = useAuth()
  const [wallet, setWallet] = useState<Wallet | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchWalletData = async () => {
      if (user) {
        try {
          const fetchedWallet = await getUserWallet(user.id)
          setWallet(fetchedWallet)
          const fetchedTransactions = await getUserTransactions(user.id)
          setTransactions(fetchedTransactions)
        } catch (error) {
          console.error("Error fetching wallet data:", error)
        } finally {
          setLoading(false)
        }
      }
    }
    fetchWalletData()
  }, [user])

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' })
  }

  if (loading) {
    return <div>Loading...</div>
  }

  if (!wallet) {
    return <div>No wallet found. Please contact support.</div>
  }

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">Wallet</h1>

      <Card>
        <CardHeader>
          <CardTitle>Available Balance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold">{formatCurrency(wallet.balance)}</div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Button asChild variant="outline">
          <Link href="/cash-in">
            <ArrowDownLeft className="mr-2 h-4 w-4" />
            Cash In
          </Link>
        </Button>
        <Button asChild variant="outline">
          <Link href="/cash-out">
            <ArrowUpRight className="mr-2 h-4 w-4" />
            Cash Out
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          {transactions.map((transaction) => (
            <div key={transaction.id} className="flex justify-between items-center py-2 border-b last:border-b-0">
              <div>
                <div className="font-medium">{transaction.description}</div>
                <div className="text-sm text-gray-500">{formatDate(transaction.createdAt.toString())}</div>
              </div>
              <div className={transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'}>
                {formatCurrency(transaction.amount)}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}

