'use client'

import { motion } from 'framer-motion'

export function AnimatedWelcome() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="text-center mb-8"
    >
      <h1 className="text-4xl font-bold text-black mb-4">
        Welcome Aboard, Seafarers!
      </h1>
      <p className="text-xl text-black">
        Your digital companion for life at sea
      </p>
    </motion.div>
  )
}

