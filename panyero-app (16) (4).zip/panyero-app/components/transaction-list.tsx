"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"

interface Transaction {
  id: string
  type: string
  description: string
  amount: number
  date: string
}

const sampleTransactions: Transaction[] = [
  {
    id: "1",
    type: "Refunded money via",
    description: "InstaPay",
    amount: 750,
    date: "8 mins ago"
  },
  {
    id: "2",
    type: "Sent money via",
    description: "InstaPay",
    amount: -750,
    date: "9 mins ago"
  },
  {
    id: "3",
    type: "Sent money via",
    description: "InstaPay",
    amount: -2000,
    date: "34 mins ago"
  },
  {
    id: "4",
    type: "Received money from",
    description: "JINNY MALIJAN LEMUS",
    amount: 2000,
    date: "45 mins ago"
  },
]

export function TransactionList() {
  const [transactions] = useState<Transaction[]>(sampleTransactions)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', {
      style: 'currency',
      currency: 'PHP'
    }).format(Math.abs(amount))
  }

  return (
    <Card className="p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Transactions</h2>
        <a href="/transactions" className="text-purple-600 text-sm">
          See all
        </a>
      </div>
      <div className="space-y-4">
        {transactions.map((transaction) => (
          <div key={transaction.id} className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500">{transaction.type}</p>
              <p className="font-medium">{transaction.description}</p>
              <p className="text-sm text-gray-500">{transaction.date}</p>
            </div>
            <span className={`font-medium ${
              transaction.amount < 0 ? 'text-gray-900' : 'text-green-600'
            }`}>
              {transaction.amount < 0 ? '- ' : '+ '}
              {formatCurrency(transaction.amount)}
            </span>
          </div>
        ))}
      </div>
    </Card>
  )
}

