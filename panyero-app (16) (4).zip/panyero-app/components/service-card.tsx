import { Card, CardContent } from "@/components/ui/card"
import { type LucideIcon } from 'lucide-react'

interface ServiceCardProps {
  icon: LucideIcon
  title: string
  amount?: string
}

export function ServiceCard({ icon: Icon, title, amount }: ServiceCardProps) {
  return (
    <Card className="hover:bg-accent">
      <CardContent className="flex flex-col items-center justify-center p-4">
        <Icon className="mb-2 h-6 w-6 text-purple-600" />
        <div className="text-sm font-medium">{title}</div>
        {amount && <div className="text-xs text-muted-foreground">{amount}</div>}
      </CardContent>
    </Card>
  )
}

