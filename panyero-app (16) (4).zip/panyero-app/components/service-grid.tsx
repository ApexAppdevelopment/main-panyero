import { Button } from "@/components/ui/button"
import { Brain, Anchor, Compass, GraduationCap, Dice1Icon as Dice, CastleIcon as Casino, Briefcase, Zap, Droplet, Wifi, Tv, TrendingUp, Smartphone, PlusSquare, MoreHorizontal, type LucideIcon } from 'lucide-react'

interface Service {
  icon: string
  label: string
  href: string
}

interface ServiceGridProps {
  services: Service[]
}

const iconMap: { [key: string]: LucideIcon } = {
  brain: Brain,
  anchor: Anchor,
  compass: Compass,
  "graduation-cap": GraduationCap,
  dice: Dice,
  casino: Casino,
  briefcase: Briefcase,
  zap: Zap,
  droplet: Droplet,
  wifi: Wifi,
  tv: Tv,
  "trending-up": TrendingUp,
  smartphone: Smartphone,
  "plus-square": PlusSquare,
  "more-horizontal": MoreHorizontal,
}

export function ServiceGrid({ services }: ServiceGridProps) {
  return (
    <div className="grid grid-cols-4 gap-4">
      {services.map((service) => {
        const Icon = iconMap[service.icon]
        return (
          <Button
            key={service.label}
            variant="outline"
            className="flex flex-col items-center justify-center h-20 bg-white"
            asChild
          >
            <a href={service.href}>
              <Icon className="h-6 w-6 mb-1 text-gray-600" />
              <span className="text-xs text-center">{service.label}</span>
            </a>
          </Button>
        )
      })}
    </div>
  )
}

