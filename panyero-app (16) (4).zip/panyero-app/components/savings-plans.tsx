"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Car, Home } from 'lucide-react'

interface SavingPlan {
  icon: any // Using any to avoid type errors with LucideIcon
  name: string
  amountLeft: number
  progress: number
}

interface SavingsPlansProps {
  plans: SavingPlan[]
}

export function SavingsPlans({ plans }: SavingsPlansProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-PH', { style: 'currency', currency: 'PHP' }).format(amount)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          My Saving Plans
          <Button variant="link" size="sm">See all</Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 gap-4">
          {plans.map((plan) => (
            <div key={plan.name} className="flex items-center justify-between border-b pb-3 last:border-b-0 last:pb-0">
              <div className="flex items-center gap-2">
                <plan.icon className="h-6 w-6 text-purple-600" />
                <div>
                  <p className="font-medium">{plan.name}</p>
                  <p className="text-sm text-muted-foreground">Amount left</p>
                  <p className="font-medium">{formatCurrency(plan.amountLeft)}</p>
                </div>
              </div>
              <Progress value={plan.progress} className="w-24" />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

