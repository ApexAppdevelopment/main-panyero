'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'

const images = [
  "https://firebasestorage.googleapis.com/v0/b/potent-bulwark-434423-t6.appspot.com/o/IMG_20241130_124522.jpg?alt=media&token=0d0c2502-1bfb-4961-9616-24bd38551cbc",
  "https://firebasestorage.googleapis.com/v0/b/potent-bulwark-434423-t6.appspot.com/o/IMG_20241130_130909.jpg?alt=media&token=a7a65442-954f-43ca-a3fe-4280f9bb3323",
  "https://firebasestorage.googleapis.com/v0/b/potent-bulwark-434423-t6.appspot.com/o/IMG_20241130_125005.jpg?alt=media&token=6a2efc5b-94f7-408f-8e2c-70cb3a1f39bc"
]

export function BackgroundCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
    }, 3000) // Change image every 3 seconds

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="fixed inset-0 z-0 overflow-hidden">
      <AnimatePresence initial={false} mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 1.5 }}
          className="absolute inset-0"
        >
          <Image
            src={images[currentIndex]}
            alt="Background"
            layout="fill"
            objectFit="cover"
            quality={100}
            priority
            className="transform-gpu"
          />
          <div className="absolute inset-0 bg-black/20" /> {/* Overlay for better text readability */}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

