import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { CreditCard } from 'lucide-react'

export default function PayBillsPage() {
  return <PlaceholderServicePage title="Pay Bills" icon={CreditCard} />
}

