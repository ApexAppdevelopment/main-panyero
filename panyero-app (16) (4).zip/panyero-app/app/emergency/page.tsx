import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { AlertTriangle } from 'lucide-react'

export default function EmergencyPage() {
  return <PlaceholderServicePage title="Emergency" icon={AlertTriangle} />
}

