"use client"

import { useState, useEffect } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Thermometer, Waves, Wind } from 'lucide-react'

export default function SeaConditionsPage() {
  const [temperature, setTemperature] = useState(20);
  const [waveHeight, setWaveHeight] = useState(1);
  const [windSpeed, setWindSpeed] = useState(10);

  useEffect(() => {
    // Simulate changing sea conditions
    const interval = setInterval(() => {
      setTemperature(prev => prev + (Math.random() - 0.5));
      setWaveHeight(prev => Math.max(0, prev + (Math.random() - 0.5)));
      setWindSpeed(prev => Math.max(0, prev + (Math.random() - 0.5) * 2));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-4">
        <h1 className="text-2xl font-bold">Sea Conditions</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Current Conditions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Thermometer className="h-6 w-6 text-red-500 mr-2" />
                <span>Temperature</span>
              </div>
              <span className="font-bold">{temperature.toFixed(1)}°C</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Waves className="h-6 w-6 text-blue-500 mr-2" />
                <span>Wave Height</span>
              </div>
              <span className="font-bold">{waveHeight.toFixed(1)} meters</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Wind className="h-6 w-6 text-gray-500 mr-2" />
                <span>Wind Speed</span>
              </div>
              <span className="font-bold">{windSpeed.toFixed(1)} knots</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  );
}

