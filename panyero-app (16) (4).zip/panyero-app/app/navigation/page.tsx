import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Compass, Map, Wind, Navigation2, Anchor, Radar, Waves, Thermometer } from 'lucide-react'
import Link from "next/link"

const navigationTools = [
  {
    icon: Compass,
    title: "Digital Compass",
    description: "Real-time magnetic heading",
    href: "/navigation/compass"
  },
  {
    icon: Map,
    title: "Route Planning",
    description: "Plan and optimize your routes",
    href: "/navigation/route-planning"
  },
  {
    icon: Wind,
    title: "Weather Updates",
    description: "Marine weather forecasts",
    href: "/navigation/weather"
  },
  {
    icon: Navigation2,
    title: "GPS Navigation",
    description: "Precise positioning system",
    href: "/navigation/gps"
  },
  {
    icon: Anchor,
    title: "Anchor Watch",
    description: "Monitor anchor position",
    href: "/navigation/anchor-watch"
  },
  {
    icon: Radar,
    title: "Radar Display",
    description: "Visualize surrounding vessels",
    href: "/navigation/radar"
  },
  {
    icon: Waves,
    title: "Tide Information",
    description: "Real-time tide data",
    href: "/navigation/tides"
  },
  {
    icon: Thermometer,
    title: "Sea Conditions",
    description: "Temperature and sea state",
    href: "/navigation/sea-conditions"
  }
]

export default function NavigationPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="space-y-6 p-4">
        <h1 className="text-2xl font-bold">Navigation Tools</h1>
        
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {navigationTools.map((tool, index) => (
            <div key={index} className="rounded-lg bg-white p-4 shadow-sm">
              <div className="flex items-center gap-4 mb-4">
                <div className="rounded-full bg-blue-100 p-3">
                  <tool.icon className="h-6 w-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h2 className="font-semibold">{tool.title}</h2>
                  <p className="text-sm text-gray-600">{tool.description}</p>
                </div>
              </div>
              <Button asChild className="w-full">
                <Link href={tool.href}>Open Tool</Link>
              </Button>
            </div>
          ))}
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

