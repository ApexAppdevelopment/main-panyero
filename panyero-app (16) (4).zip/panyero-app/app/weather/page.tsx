import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { CloudRain } from 'lucide-react'

export default function WeatherPage() {
  return <PlaceholderServicePage title="Weather" icon={CloudRain} />
}

