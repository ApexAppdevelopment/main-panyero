import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { ServiceGrid } from "@/components/service-grid"

const services = [
  { icon: "zap", label: "Electricity", href: "/electricity" },
  { icon: "droplet", label: "Water", href: "/water" },
  { icon: "wifi", label: "Internet", href: "/internet" },
  { icon: "tv", label: "Television", href: "/television" },
  { icon: "trending-up", label: "Investment", href: "/investment" },
  { icon: "smartphone", label: "Mobile", href: "/mobile" },
  { icon: "plus-square", label: "Medical", href: "/medical" },
  { icon: "more-horizontal", label: "Other", href: "/other" },
  // Add more services as needed
]

export default function EservicesPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Eservices</h1>
        <ServiceGrid services={services} />
      </div>
      <BottomNav />
    </main>
  )
}

