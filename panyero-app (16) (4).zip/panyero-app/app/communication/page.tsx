import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { MessageSquare } from 'lucide-react'

export default function CommunicationPage() {
  return <PlaceholderServicePage title="Communication" icon={MessageSquare} />
}

