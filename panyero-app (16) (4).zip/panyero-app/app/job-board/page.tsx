import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Briefcase } from 'lucide-react'

export default function JobBoardPage() {
  return <PlaceholderServicePage title="Job Board" icon={Briefcase} />
}

