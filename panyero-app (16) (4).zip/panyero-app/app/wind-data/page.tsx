import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Wind } from 'lucide-react'

export default function WindDataPage() {
  return <PlaceholderServicePage title="Wind Data" icon={Wind} />
}

