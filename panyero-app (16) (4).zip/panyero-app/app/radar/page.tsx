import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Radar } from 'lucide-react'

export default function RadarPage() {
  return <PlaceholderServicePage title="Radar" icon={Radar} />
}

