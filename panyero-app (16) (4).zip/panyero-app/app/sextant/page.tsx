import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Sunrise } from 'lucide-react'

export default function SextantPage() {
  return <PlaceholderServicePage title="Sextant" icon={Sunrise} />
}

