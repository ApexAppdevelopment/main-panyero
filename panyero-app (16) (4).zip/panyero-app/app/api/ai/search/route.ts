import { NextResponse } from 'next/server'

const API_KEY = process.env.RAPIDAPI_KEY
const API_HOST = 'contextualwebsearch-websearch-v1.p.rapidapi.com'

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const query = searchParams.get('q')

  if (!query) {
    return NextResponse.json({ error: 'No search query provided' }, { status: 400 })
  }

  const url = `https://${API_HOST}/api/Search/WebSearchAPI?q=${encodeURIComponent(query)}&pageNumber=1&pageSize=10&autoCorrect=true`

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': API_KEY!,
        'X-RapidAPI-Host': API_HOST
      }
    })

    const data = await response.json()

    if (!response.ok) {
      throw new Error(data.message || 'Failed to fetch search results')
    }

    const results = data.value.map((item: any) => ({
      title: item.title,
      snippet: item.description,
      link: item.url
    }))

    return NextResponse.json({ results })
  } catch (error) {
    console.error('Error in search API:', error)
    return NextResponse.json({ error: 'Failed to perform search' }, { status: 500 })
  }
}

