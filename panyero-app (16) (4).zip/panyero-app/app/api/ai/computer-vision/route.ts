import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: Request) {
  try {
    const formData = await req.formData()
    const image = formData.get('image') as Blob

    if (!image) {
      return NextResponse.json({ error: 'No image provided' }, { status: 400 })
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4-vision-preview",
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: "What's in this image? Provide a detailed description." },
            {
              type: "image_url",
              image_url: {
                url: `data:${image.type};base64,${Buffer.from(await image.arrayBuffer()).toString('base64')}`,
              },
            },
          ],
        },
      ],
    })

    const description = response.choices[0].message.content

    return NextResponse.json({ description })
  } catch (error) {
    console.error('Error in computer-vision API:', error)
    return NextResponse.json({ error: 'Failed to analyze image' }, { status: 500 })
  }
}

