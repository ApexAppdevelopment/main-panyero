import { NextResponse } from 'next/server'
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function POST(req: Request) {
  try {
    const { text, standard } = await req.json()

    const completion = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: `You are a compliance expert for ${standard}. Check if the given text complies with the standard.` },
        { role: "user", content: `Check if this text complies with ${standard}: ${text}` }
      ],
    })

    const result = completion.choices[0].message.content
    const compliant = result.toLowerCase().includes("compliant")

    return NextResponse.json({ compliant, details: result })
  } catch (error) {
    console.error('Error in compliance API:', error)
    return NextResponse.json({ error: 'Failed to check compliance' }, { status: 500 })
  }
}

