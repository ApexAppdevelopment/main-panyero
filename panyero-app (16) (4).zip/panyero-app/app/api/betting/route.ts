import { NextResponse } from 'next/server'
import { auth } from '@/lib/firebase'
import { getWallet, updateWalletBalance, createTransaction } from '@/lib/wallet-service'

export async function POST(req: Request) {
  try {
    const { gameId, outcome, amount, odds } = await req.json()
    const user = auth.currentUser

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const wallet = await getWallet(user.uid)

    if (!wallet) {
      return NextResponse.json({ error: 'Wallet not found' }, { status: 404 })
    }

    if (wallet.balance < amount) {
      return NextResponse.json({ error: 'Insufficient funds' }, { status: 400 })
    }

    const updatedWallet = await updateWalletBalance(user.uid, amount, 'debit')
    await createTransaction(user.uid, 'bet', -amount, 'PHP', `Bet on ${gameId} - ${outcome}`)

    // Here you would typically record the bet in your database
    // For this example, we'll just return a success message

    return NextResponse.json({ 
      success: true, 
      message: `Bet of ${amount} placed on ${outcome} for game ${gameId}`,
      newBalance: updatedWallet.balance
    })
  } catch (error) {
    console.error('Error in betting API:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

