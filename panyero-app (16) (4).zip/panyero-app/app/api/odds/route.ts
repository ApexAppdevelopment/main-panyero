import { NextResponse } from 'next/server'

const API_KEY = 'c594b0f0e9b78fbce413ec1552bf1d52'
const API_HOST = 'https://api.the-odds-api.com'

export async function GET() {
  try {
    const response = await fetch(`${API_HOST}/v4/sports/upcoming/odds/?apiKey=${API_KEY}&regions=us&markets=h2h&oddsFormat=decimal`)
    if (!response.ok) {
      throw new Error('Failed to fetch odds')
    }
    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error('Error fetching odds:', error)
    return NextResponse.json({ error: 'Failed to fetch odds' }, { status: 500 })
  }
}

