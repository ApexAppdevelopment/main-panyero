"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Loader2, LineChart } from 'lucide-react'
import { toast } from "sonner"

export default function PredictiveAnalyticsPage() {
  const [historicalData, setHistoricalData] = useState("")
  const [predictionPeriod, setPredictionPeriod] = useState("")
  const [result, setResult] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch("/api/ai/predictive-analytics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ historicalData, predictionPeriod }),
      })
      const result = await response.json()
      if (response.ok) {
        setResult(result.prediction)
        toast.success("Prediction generated successfully!")
      } else {
        throw new Error(result.error || "Something went wrong")
      }
    } catch (error) {
      toast.error("Failed to generate prediction")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold flex items-center">
          <TrendingUp className="mr-2 h-6 w-6" />
          AI Predictive Analytics
        </h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Generate Predictions</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Textarea
                placeholder="Enter historical data (CSV format)"
                value={historicalData}
                onChange={(e) => setHistoricalData(e.target.value)}
                required
                className="h-40"
              />
              <Input
                type="number"
                placeholder="Prediction period (in days)"
                value={predictionPeriod}
                onChange={(e) => setPredictionPeriod(e.target.value)}
                required
              />
              <Button type="submit" disabled={loading} className="w-full">
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Prediction...
                  </>
                ) : (
                  "Generate Prediction"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Prediction Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="whitespace-pre-wrap">{result}</div>
              <LineChart className="w-full h-48 mt-4" />
            </CardContent>
          </Card>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

