import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Code } from 'lucide-react'

export default function CodeGenerationPage() {
  return <PlaceholderServicePage title="AI Code Generation" icon={Code} />
}

