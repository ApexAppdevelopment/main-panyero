import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { FileVideo } from 'lucide-react'

export default function VideoGenerationPage() {
  return <PlaceholderServicePage title="AI Video Generation" icon={FileVideo} />
}

