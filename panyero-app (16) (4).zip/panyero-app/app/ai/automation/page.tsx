import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { BotIcon as Robot } from 'lucide-react'

export default function AutomationPage() {
  return <PlaceholderServicePage title="AI Automation" icon={Robot} />
}

