import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { MessageCircle, Phone, Mail, FileText } from 'lucide-react'
import Link from "next/link"

const faqCategories = [
  { title: "Account & Security", count: 12 },
  { title: "Payments & Transfers", count: 15 },
  { title: "Seafarer Services", count: 8 },
  { title: "Technical Issues", count: 10 },
]

export default function HelpPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="space-y-6 p-4">
        <h1 className="text-2xl font-bold">Help & Support</h1>

        <div className="grid gap-4">
          <div className="rounded-lg bg-white p-4 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <MessageCircle className="h-6 w-6 text-blue-600" />
              <h2 className="font-semibold">Chat with Support</h2>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Get instant help from our support team
            </p>
            <Button className="w-full">Start Chat</Button>
          </div>

          <div className="rounded-lg bg-white p-4 shadow-sm">
            <h2 className="font-semibold mb-4">Contact Us</h2>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-gray-600" />
                <span>+1234567890</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-gray-600" />
                <span>support@panyero.com</span>
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-white p-4 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <MessageCircle className="h-6 w-6 text-blue-600" />
              <h2 className="font-semibold">Chat with Support</h2>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Get instant help from our support team
            </p>
            <Button className="w-full">Start Chat</Button>
          </div>

          <div className="rounded-lg bg-white p-4 shadow-sm">
            <h2 className="font-semibold mb-4">Contact Us</h2>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-gray-600" />
                <span>+1234567890</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-gray-600" />
                <span>support@panyero.com</span>
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-white p-4 shadow-sm">
            <h2 className="font-semibold mb-4">FAQ Categories</h2>
            <div className="space-y-3">
              {faqCategories.map((category, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100"
                >
                  <span>{category.title}</span>
                  <span className="text-sm text-gray-500">{category.count} articles</span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-lg bg-white p-4 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <FileText className="h-6 w-6 text-blue-600" />
              <h2 className="font-semibold">User Guides</h2>
            </div>
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                Getting Started Guide
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Security Best Practices
              </Button>
              <Button variant="outline" className="w-full justify-start">
                Seafarer Documentation
              </Button>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

