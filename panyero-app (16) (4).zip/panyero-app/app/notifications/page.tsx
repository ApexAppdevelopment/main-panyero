import { StickyHeader } from "@/components/ui/sticky-header"
import { Bell, Gift, CreditCard, Wallet, ArrowUpRight } from 'lucide-react'

const notifications = [
  {
    id: 1,
    icon: Gift,
    title: "Welcome Bonus!",
    description: "Get 100% bonus on your first deposit up to ₱1,000",
    time: "Just now",
    isNew: true,
  },
  {
    id: 2,
    icon: CreditCard,
    title: "Card Verification Required",
    description: "Please verify your card to enable international transactions",
    time: "2 hours ago",
    isNew: true,
  },
  {
    id: 3,
    icon: Wallet,
    title: "Balance Update",
    description: "You've received ₱500 from John Doe",
    time: "5 hours ago",
    isNew: false,
  },
  {
    id: 4,
    icon: ArrowUpRight,
    title: "Money Sent",
    description: "Successfully sent ₱1,000 to Jane Smith",
    time: "1 day ago",
    isNew: false,
  },
]

export default function NotificationsPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Notifications</h1>
          <p className="text-sm text-gray-500">Stay updated with your account activity</p>
        </div>

        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`rounded-lg bg-white p-4 shadow-sm ${
                notification.isNew ? "border-l-4 border-green-500" : ""
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-gray-100 p-2">
                  <notification.icon className="h-6 w-6 text-gray-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h2 className="font-medium">{notification.title}</h2>
                    <span className="text-xs text-gray-500">{notification.time}</span>
                  </div>
                  <p className="mt-1 text-sm text-gray-600">
                    {notification.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {notifications.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12">
            <Bell className="h-12 w-12 text-gray-400" />
            <h2 className="mt-4 text-lg font-medium">No notifications yet</h2>
            <p className="mt-2 text-center text-sm text-gray-500">
              We'll notify you when there's any activity on your account
            </p>
          </div>
        )}
      </div>

    </main>
  )
}

