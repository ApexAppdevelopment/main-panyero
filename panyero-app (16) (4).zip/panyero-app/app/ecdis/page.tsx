import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Monitor } from 'lucide-react'

export default function ECDISPage() {
  return <PlaceholderServicePage title="ECDIS" icon={Monitor} />
}

