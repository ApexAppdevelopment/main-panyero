import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { SirenIcon as Sonar } from 'lucide-react'

export default function SonarPage() {
  return <PlaceholderServicePage title="Sonar" icon={Sonar} />
}

