import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Hotel } from 'lucide-react'

export default function HotelsPage() {
  return <PlaceholderServicePage title="Hotels" icon={Hotel} />
}

