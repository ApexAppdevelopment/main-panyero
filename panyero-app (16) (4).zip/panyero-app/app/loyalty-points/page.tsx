import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Award } from 'lucide-react'

export default function LoyaltyPointsPage() {
  return <PlaceholderServicePage title="Loyalty Points" icon={Award} />
}

