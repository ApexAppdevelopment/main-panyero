import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Anchor, Navigation, AlertTriangle, FileText } from 'lucide-react'

const maritimeServices = [
  { icon: Anchor, title: "Ship Management", description: "Manage your vessel operations" },
  { icon: Navigation, title: "Navigation Tools", description: "Access navigation and weather data" },
  { icon: AlertTriangle, title: "Safety Protocols", description: "View and manage safety procedures" },
  { icon: FileText, title: "Documentation", description: "Access and manage maritime documents" },
]

export default function MaritimePage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Maritime Services</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {maritimeServices.map((service, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <service.icon className="mr-2 h-5 w-5 text-purple-600" />
                  {service.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p>{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      <BottomNav />
    </main>
  )
}

