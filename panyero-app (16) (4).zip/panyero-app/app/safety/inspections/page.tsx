"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock, CheckCircle, XCircle, Plus } from 'lucide-react'
import { toast } from "sonner"

interface Inspection {
  id: string
  name: string
  date: string
  status: "scheduled" | "completed" | "overdue"
}

export default function SafetyInspectionsPage() {
  const [inspections, setInspections] = useState<Inspection[]>([
    { id: "1", name: "Monthly Safety Inspection", date: "2023-07-15", status: "scheduled" },
    { id: "2", name: "Fire Safety Check", date: "2023-06-30", status: "completed" },
    { id: "3", name: "Emergency Equipment Inspection", date: "2023-06-15", status: "overdue" },
  ])
  const [newInspection, setNewInspection] = useState({ name: "", date: "" })

  const addInspection = () => {
    if (newInspection.name && newInspection.date) {
      const newInsp: Inspection = {
        id: Date.now().toString(),
        name: newInspection.name,
        date: newInspection.date,
        status: "scheduled",
      }
      setInspections([...inspections, newInsp])
      setNewInspection({ name: "", date: "" })
      toast.success("Inspection scheduled successfully")
    } else {
      toast.error("Please enter both inspection name and date")
    }
  }

  const updateInspectionStatus = (id: string, status: Inspection['status']) => {
    setInspections(inspections.map(insp => 
      insp.id === id ? { ...insp, status } : insp
    ))
    toast.success(`Inspection status updated to ${status}`)
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Safety Inspections</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Schedule New Inspection</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="inspection-name">Inspection Name</Label>
                <Input
                  id="inspection-name"
                  value={newInspection.name}
                  onChange={(e) => setNewInspection({...newInspection, name: e.target.value})}
                  placeholder="Enter inspection name"
                />
              </div>
              <div>
                <Label htmlFor="inspection-date">Inspection Date</Label>
                <Input
                  id="inspection-date"
                  type="date"
                  value={newInspection.date}
                  onChange={(e) => setNewInspection({...newInspection, date: e.target.value})}
                />
              </div>
              <Button onClick={addInspection} className="w-full">
                <Plus className="mr-2 h-4 w-4" /> Schedule Inspection
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Inspections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {inspections.map((insp) => (
                <div key={insp.id} className="flex items-center justify-between p-2 bg-white rounded-lg shadow">
                  <div>
                    <p className="font-semibold">{insp.name}</p>
                    <p className="text-sm text-gray-500">
                      <Calendar className="inline-block mr-1 h-4 w-4" />
                      {new Date(insp.date).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 text-xs font-semibold rounded ${
                      insp.status === 'completed' ? 'bg-green-100 text-green-800' :
                      insp.status === 'overdue' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {insp.status.charAt(0).toUpperCase() + insp.status.slice(1)}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateInspectionStatus(insp.id, 'completed')}
                    >
                      <CheckCircle className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => updateInspectionStatus(insp.id, 'overdue')}
                    >
                      <XCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

