"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle, RotateCcw } from 'lucide-react'
import { toast } from "sonner"

interface EquipmentItem {
  id: string
  name: string
  checked: boolean
  lastChecked: string | null
}

export default function SafetyEquipmentChecklistPage() {
  const [equipmentList, setEquipmentList] = useState<EquipmentItem[]>([
    { id: "1", name: "Life Jackets", checked: false, lastChecked: null },
    { id: "2", name: "Fire Extinguishers", checked: false, lastChecked: null },
    { id: "3", name: "Emergency Flares", checked: false, lastChecked: null },
    { id: "4", name: "First Aid Kit", checked: false, lastChecked: null },
    { id: "5", name: "Emergency Radio", checked: false, lastChecked: null },
  ])

  const toggleEquipment = (id: string) => {
    setEquipmentList(equipmentList.map(item => 
      item.id === id 
        ? { ...item, checked: !item.checked, lastChecked: item.checked ? null : new Date().toISOString() } 
        : item
    ))
  }

  const resetChecklist = () => {
    setEquipmentList(equipmentList.map(item => ({ ...item, checked: false, lastChecked: null })))
    toast.success("Checklist reset successfully")
  }

  const submitChecklist = () => {
    if (equipmentList.every(item => item.checked)) {
      toast.success("All safety equipment checked successfully!")
    } else {
      toast.error("Please check all safety equipment before submitting")
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Safety Equipment Checklist</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Equipment List</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {equipmentList.map((item) => (
                <div key={item.id} className="flex items-center space-x-2">
                  <Checkbox
                    id={item.id}
                    checked={item.checked}
                    onCheckedChange={() => toggleEquipment(item.id)}
                  />
                  <label
                    htmlFor={item.id}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {item.name}
                  </label>
                  {item.checked ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500" />
                  )}
                  {item.lastChecked && (
                    <span className="text-xs text-gray-500">
                      Last checked: {new Date(item.lastChecked).toLocaleString()}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="flex space-x-4">
          <Button onClick={submitChecklist} className="flex-1">
            <CheckCircle className="mr-2 h-4 w-4" /> Submit Checklist
          </Button>
          <Button onClick={resetChecklist} variant="outline" className="flex-1">
            <RotateCcw className="mr-2 h-4 w-4" /> Reset Checklist
          </Button>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

