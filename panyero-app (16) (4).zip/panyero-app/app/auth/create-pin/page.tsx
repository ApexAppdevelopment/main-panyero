'use client'

import Image from "next/image"
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "sonner"
import { useAuth } from "@/contexts/auth-context"

export default function CreatePinPage() {
  const [pin, setPin] = useState('')
  const [confirmPin, setConfirmPin] = useState('')
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const { user, updateUserProfile } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (pin !== confirmPin) {
      toast.error("PINs do not match")
      return
    }
    if (pin.length !== 4) {
      toast.error("PIN must be 4 digits")
      return
    }
    setLoading(true)
    try {
      await updateUserProfile({ pin })
      toast.success("PIN created successfully")
      router.push('/')
    } catch (error) {
      console.error("Error creating PIN:", error)
      toast.error("Failed to create PIN")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        <div className="flex flex-col items-center mb-8">
          <Image
            src="https://firebasestorage.googleapis.com/v0/b/aitek2023-8f504.appspot.com/o/logo-1024px.png?alt=media&token=302e9605-3d4c-4e45-bce6-7676d037c852"
            alt="Panyero Logo"
            width={150}
            height={150}
            className="mb-8"
            priority
          />
        </div>
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Create Your PIN</CardTitle>
            <CardDescription>Please set a 4-digit PIN for your account</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Input
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="Enter 4-digit PIN"
                  required
                />
              </div>
              <div>
                <Input
                  type="password"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={4}
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value)}
                  placeholder="Confirm 4-digit PIN"
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Creating PIN..." : "Create PIN"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

