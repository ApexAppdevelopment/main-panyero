import { PlaceholderServicePage } from "@/components/placeholder-service-page"
import { Thermometer } from 'lucide-react'

export default function SeaTempPage() {
  return <PlaceholderServicePage title="Sea Temperature" icon={Thermometer} />
}

